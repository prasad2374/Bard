import datetime
import speech_recognition as sr
import pyttsx3


# Import the BardCookies and YOLOv8 libraries
from bardapi import BardCookies
from ultralytics import YOLO
from ultralytics.models.yolo.detect.predict import DetectionPredictor
import cv2

# Create a BardCookies object using the user's cookies
cookie_dict = {
    "__Secure-1PSID": "cQh2Fv-LC0pk4z1QZ1yhmHGvBTj9H_hsCcuTSTfgVv3oz_3FnejGyvb-xbePeP8oqzVWcw.",
    "__Secure-1PSIDTS": "sidts-CjIB3e41hcsFjvymn-ETOB8KEb1LuyadYmUsrUbVQdW4i3PaAaEWAOGiDkODu0P9roYVUhAA",
    "__Secure-1PSIDCC": "ACA-OxPn3Enn30zoSumdPmIWuyZeRVznQGql7Kof89vnETYB0K_NVq2cKx74gKkI7vVGN-k"
}
bard = BardCookies(cookie_dict=cookie_dict)

# Initialize a speech recognition engine
r = sr.Recognizer()

# Initialize a PyTTSX3 engine
engine = pyttsx3.init()

# Initialize a YOLOv8 model
model = YOLO("yolov8n.pt")

# Start the loop
while True:
    # Capture an image of the object
    image = cv2.imread(0)

    # Detect the object in the image
    results = model(image)

    # Get the object's class name
    class_name = results.pandas().xyxy[0]["name"]

    # Send the object's class name to Bard as a query
    query = class_name
    reply = bard.get_answer(query)['content']

    # Speak the Bard's response
    engine.say(reply)
    engine.runAndWait()

    # Press q to quit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the webcam
cv2.destroyAllWindows()