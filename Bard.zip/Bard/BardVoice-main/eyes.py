import torch
import cv2
from pathlib import Path
from models.experimental import attempt_load
from utils.general import non_max_suppression, scale_coords
from utils.datasets import LoadStreams, LoadImages
from utils.torch_utils import select_device, load_classifier

def live_object_detection(weights, source, img_size=640, conf_thres=0.25, iou_thres=0.45, view_img=True, save_txt=False):
    # Initialize device (default is GPU)
    device = select_device('0')  # '0' is the GPU device index
    half = device.type != 'cpu'  # Half precision only supported on CUDA

    # Load YOLOv5 model
    model = attempt_load(weights, map_location=device)
    imgsz = check_img_size(img_size, s=model.stride.max())  # Check img_size
    if half:
        model.half()

    # Set Dataloader
    dataset = LoadStreams(source, img_size=imgsz)

    # Get class labels
    names = model.module.names if hasattr(model, 'module') else model.names

    for path, img, im0s, vid_cap in dataset:
        img = torch.from_numpy(img).to(device)
        img = img.half() if half else img.float()  # to FP16/32
        img /= 255.0  # 0 - 255 to 0.0 - 1.0
        if img.ndimension() == 3:
            img = img.unsqueeze(0)

        # Inference
        pred = model(img, augment=False)[0]

        # Apply NMS
        pred = non_max_suppression(pred, conf_thres, iou_thres, classes=None, agnostic=False)

        # Process detections
        for i, det in enumerate(pred):
            if len(det):
                det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0s.shape).round()
                for *xyxy, conf, cls in det:
                    label = f'{names[int(cls)]} {conf:.2f}'
                    plot_one_box(xyxy, im0s, label=label, color=colors(int(cls)), line_thickness=3)

        # Display the image with bounding boxes
        if view_img:
            cv2.imshow('YOLOv5 Live Object Detection', im0s)

        # Save detected objects to a text file (optional)
        if save_txt:
            save_path = str(Path('inference/output') / Path(path).stem)
            txt_path = save_path + '.txt'
            save_dir = Path(txt_path).parent
            save_dir.mkdir(parents=True, exist_ok=True)

            with open(txt_path, 'a') as file:
                file.write(label + '\n')

        # Exit with 'q' key
        if cv2.waitKey(1) == ord('q'):
            cv2.destroyAllWindows()
            break

if __name__ == "__main__":
    weights = 'yolov5s.pt'  # Replace with the path to your YOLOv5 model weights
    source = 0  # 0 for the default camera, or provide a video file path
    live_object_detection(weights, source)
