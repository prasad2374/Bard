from bardapi import BardCookies
import datetime
import speech_recognition as sr
import pyttsx3

r=sr.Recognizer()


cookie_dict={ 
    "__Secure-1PSID" :"dQh2FkDoyudYV77g8iUn82kohQBhyrklZ4rMPMQOTW9S9xkIqCsSImih-NiBzcgzGIAZ4A.",
    "__Secure-1PSIDTS" :"sidts-CjEBPVxjSjBwwJs2_fk9KzsVQSz-EOABWQG0rG_wF3Sfjs56fCI9ztzPso1dzpVIDbaEEAA",
    "__Secure-1PSIDCC" :"ABTWhQFFHR3dVWClDOwFtMEC9j9Yg8HDcqrDparzEfpcOTz_9YkSeL2PxQ2t2-zKUv0mwCU1IeI"
    }
bard = BardCookies(cookie_dict=cookie_dict)
engine=pyttsx3.init()
while True:
    with sr.Microphone() as source:
        r.adjust_for_ambient_noise(source)
        print("Ask your query")

        audio=r.listen(source)
        Query = r.recognize_google(audio)
        print("You said: ",Query)

    
    
    reply = bard.get_answer(Query)['content']
    
    print(reply)
    engine.say(reply)
    engine.runAndWait()