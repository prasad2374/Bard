import torch
from ultralytics import YOLO
import cv2

# Specify the GPU device (or "cuda" for the default GPU)


model = YOLO("yolov8x.pt")

results = model.predict(source="0", show=True)
print(results)
